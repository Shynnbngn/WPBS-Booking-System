/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Client;
import util.DatabaseConnection;

/**
 *
 * @author PC-01
 */
public class ClientController {

    public void addClient(Client cl) {
        try {
            Connection c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("INSERT INTO clients_profile (groom_name, bride_name, groom_age, bride_age, address, contact) VALUES (?,?,?,?,?,?)");
            ps.setString(1, cl.getGroom_name());
            ps.setString(2, cl.getBride_name());
            ps.setString(3, cl.getGroom_age());
            ps.setString(4, cl.getBride_age());
            ps.setString(5, cl.getAddress());
            ps.setString(6, cl.getContact());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Successfully saved!");
        } catch (SQLException ex) {
            Logger.getLogger(ClientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void editClient(Client cl) {
        //always use PK
        try {
            Connection c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("UPDATE clients_profile SET groom_name = ?, bride_name = ?, groom_age = ?, bride_age =?, address = ?, contact = ? WHERE idclients_profile = ?");
            ps.setString(1, cl.getGroom_name());
            ps.setString(2, cl.getBride_name());
            ps.setString(3, cl.getGroom_age());
            ps.setString(4, cl.getBride_age());
            ps.setString(5, cl.getAddress());
            ps.setString(6, cl.getContact());
            ps.setInt(7, cl.getId());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Successfully updated!");

        } catch (SQLException ex) {
            Logger.getLogger(ClientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void removeClientsProfile(Client cl) {

        try {
            Connection c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("DELETE FROM clients_profile WHERE idclients_profile= ?");
            ps.setInt(1, cl.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ClientController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ArrayList<Client> getClientList(String n) {
        ArrayList<Client> clientList = new ArrayList<>();

        Connection c = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = c.prepareStatement("SELECT * FROM clients_profile WHERE (groom_name LIKE ?) OR (bride_name LIKE ?) OR (groom_age LIKE ?) OR (bride_age LIKE ?) OR (address LIKE ?) OR (contact LIKE ?)");
            ps.setString(1, n + "%");
            ps.setString(2, n + "%");
            ps.setString(3, n + "%");
            ps.setString(4, n + "%");
            ps.setString(5, n + "%");
            ps.setString(6, n + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Client cl = new Client();
                cl.setId(rs.getInt("idclients_profile"));
                cl.setGroom_name(rs.getString("groom_name"));
                cl.setBride_name(rs.getString("bride_name"));
                cl.setGroom_age(rs.getString("groom_age"));
                cl.setBride_age(rs.getString("bride_age"));
                cl.setAddress(rs.getString("address"));
                cl.setContact(rs.getString("contact"));
                clientList.add(cl);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

        return clientList;

    }

    public ArrayList<Client> getClientList() {
        ArrayList<Client> clientList = new ArrayList<>();

        Connection c = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = c.prepareStatement("SELECT * FROM clients_profile");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Client cl = new Client();
                cl.setId(rs.getInt("idclients_profile"));
                cl.setGroom_name(rs.getString("groom_name"));
                cl.setBride_name(rs.getString("bride_name"));
                cl.setGroom_age(rs.getString("groom_age"));
                cl.setBride_age(rs.getString("bride_age"));
                cl.setAddress(rs.getString("address"));
                cl.setContact(rs.getString("contact"));
                clientList.add(cl);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

        return clientList;
    }

}

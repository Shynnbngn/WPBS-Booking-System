/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.BookingClient;
import util.DatabaseConnection;

/**
 *
 * @author PC-01
 */
public class BookingClientController extends DatabaseConnection{

    public void bookClient(BookingClient bcl) {
        try {
             c = DatabaseConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("INSERT INTO clients_booking (cb_grname, cb_brname, cb_grage, cb_brage, cb_address, cb_contact, cb_motif, cb_reception, cb_church, cb_wedding_date, cb_wedding_packages) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, bcl.getBcl_groom_name());
            ps.setString(2, bcl.getBcl_bride_name());
            ps.setString(3, bcl.getBcl_groom_age());
            ps.setString(4, bcl.getBcl_bride_age());
            ps.setString(5, bcl.getBcl_address());
            ps.setString(6, bcl.getBcl_contact());
            ps.setString(7, bcl.getBcl_motif());
            ps.setString(8, bcl.getBcl_reception());
            ps.setString(9, bcl.getBcl_church());
            ps.setString(10, bcl.getBcl_wedding_date());
            ps.setString(11, bcl.getBcl_wedding_package());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Successfully book client!");
        } catch (SQLException ex) {
            Logger.getLogger(BookingClientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ArrayList<BookingClient> getBookingClientList(String n) {
        ArrayList<BookingClient> bookingClientList = new ArrayList<>();

         c = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = c.prepareStatement("SELECT * FROM clients_booking WHERE (cb_grname LIKE ?) OR (cb_brname LIKE ?) OR (cb_grage LIKE ?) OR (cb_brage LIKE ?) OR (cb_address LIKE ?) OR (cb_contact LIKE ?) OR (cb_motif LIKE ?) OR (cb_reception LIKE ?) OR (cb_church LIKE ?) OR (cb_wedding_date LIKE ?) OR (cb_wedding_packages LIKE ?)");
            ps.setString(1, n + "%");
            ps.setString(2, n + "%");
            ps.setString(3, n + "%");
            ps.setString(4, n + "%");
            ps.setString(5, n + "%");
            ps.setString(6, n + "%");
            ps.setString(7, n + "%");
            ps.setString(8, n + "%");
            ps.setString(9, n + "%");
            ps.setString(10, n + "%");
            ps.setString(11, n + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                BookingClient bcl = new BookingClient();
                bcl.setId(rs.getInt("idclients_booking"));
                bcl.setBcl_groom_name(rs.getString("cb_grname"));
                bcl.setBcl_bride_name(rs.getString("cb_brname"));
                bcl.setBcl_groom_age(rs.getString("cb_grage"));
                bcl.setBcl_bride_age(rs.getString("cb_brage"));
                bcl.setBcl_address(rs.getString("cb_address"));
                bcl.setBcl_contact(rs.getString("cb_contact"));
                bcl.setBcl_motif(rs.getString("cb_motif"));
                bcl.setBcl_reception(rs.getString("cb_reception"));
                bcl.setBcl_church(rs.getString("cb_church"));
                bcl.setBcl_wedding_date(rs.getString("cb_wedding_date"));
                bcl.setBcl_wedding_package(rs.getString("cb_wedding_packages"));
                bookingClientList.add(bcl);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BookingClient.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bookingClientList;

    }

    public ArrayList<BookingClient> getBookingClientList() {
        ArrayList<BookingClient> bookingClientList = new ArrayList<>();

         c = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = c.prepareStatement("SELECT * FROM clients_booking");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                BookingClient bcl = new BookingClient();
                bcl.setId(rs.getInt("idclients_booking"));
                bcl.setBcl_groom_name(rs.getString("cb_grname"));
                bcl.setBcl_bride_name(rs.getString("cb_brname"));
                bcl.setBcl_groom_age(rs.getString("cb_grage"));
                bcl.setBcl_bride_age(rs.getString("cb_brage"));
                bcl.setBcl_address(rs.getString("cb_address"));
                bcl.setBcl_contact(rs.getString("cb_contact"));
                bcl.setBcl_motif(rs.getString("cb_motif"));
                bcl.setBcl_reception(rs.getString("cb_reception"));
                bcl.setBcl_church(rs.getString("cb_church"));
                bcl.setBcl_wedding_date(rs.getString("cb_wedding_date"));
                bcl.setBcl_wedding_package(rs.getString("cb_wedding_packages"));
                bookingClientList.add(bcl);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BookingClient.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bookingClientList;
    }

}

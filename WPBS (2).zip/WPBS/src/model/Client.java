/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author PC-01
 */
public class Client {

    private int id;
    private String groom_name;
    private String bride_name;
    private String groom_age;
    private String bride_age;
    private String address;
    private String contact;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the groom_name
     */
    public String getGroom_name() {
        return groom_name;
    }

    /**
     * @param groom_name the groom_name to set
     */
    public void setGroom_name(String groom_name) {
        this.groom_name = groom_name;
    }

    /**
     * @return the bride_name
     */
    public String getBride_name() {
        return bride_name;
    }

    /**
     * @param bride_name the bride_name to set
     */
    public void setBride_name(String bride_name) {
        this.bride_name = bride_name;
    }

    /**
     * @return the groom_age
     */
    public String getGroom_age() {
        return groom_age;
    }

    /**
     * @param groom_age the groom_age to set
     */
    public void setGroom_age(String groom_age) {
        this.groom_age = groom_age;
    }

    /**
     * @return the bride_rage
     */
    public String getBride_age() {
        return bride_age;
    }

    /**
     * @param bride_rage the bride_rage to set
     */
    public void setBride_age(String bride_rage) {
        this.bride_age = bride_rage;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author PC-01
 */
public class Planner {

    private int id;
    private String planner_name;
    private String planner_username;
    private String planner_password;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the planner_name
     */
    public String getPlanner_name() {
        return planner_name;
    }

    /**
     * @param planner_name the planner_name to set
     */
    public void setPlanner_name(String planner_name) {
        this.planner_name = planner_name;
    }

    /**
     * @return the planner_username
     */
    public String getPlanner_username() {
        return planner_username;
    }

    /**
     * @param planner_username the planner_username to set
     */
    public void setPlanner_username(String planner_username) {
        this.planner_username = planner_username;
    }

    /**
     * @return the planner_password
     */
    public String getPlanner_password() {
        return planner_password;
    }

    /**
     * @param planner_password the planner_password to set
     */
    public void setPlanner_password(String planner_password) {
        this.planner_password = planner_password;
    }

}

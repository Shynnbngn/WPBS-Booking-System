/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author PC-01
 */
public class BookingClient {

    private int id;
    private String bcl_groom_name;
    private String bcl_bride_name;
    private String bcl_groom_age;
    private String bcl_bride_age;
    private String bcl_address;
    private String bcl_contact;
    private String bcl_motif;
    private String bcl_reception;
    private String bcl_church;
    private String bcl_wedding_date;
    private String bcl_wedding_package;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the bcl_groom_name
     */
    public String getBcl_groom_name() {
        return bcl_groom_name;
    }

    /**
     * @param bcl_groom_name the bcl_groom_name to set
     */
    public void setBcl_groom_name(String bcl_groom_name) {
        this.bcl_groom_name = bcl_groom_name;
    }

    /**
     * @return the bcl_bride_name
     */
    public String getBcl_bride_name() {
        return bcl_bride_name;
    }

    /**
     * @param bcl_bride_name the bcl_bride_name to set
     */
    public void setBcl_bride_name(String bcl_bride_name) {
        this.bcl_bride_name = bcl_bride_name;
    }

    /**
     * @return the bcl_groom_age
     */
    public String getBcl_groom_age() {
        return bcl_groom_age;
    }

    /**
     * @param bcl_groom_age the bcl_groom_age to set
     */
    public void setBcl_groom_age(String bcl_groom_age) {
        this.bcl_groom_age = bcl_groom_age;
    }

    /**
     * @return the bcl_bride_age
     */
    public String getBcl_bride_age() {
        return bcl_bride_age;
    }

    /**
     * @param bcl_bride_age the bcl_bride_age to set
     */
    public void setBcl_bride_age(String bcl_bride_age) {
        this.bcl_bride_age = bcl_bride_age;
    }

    /**
     * @return the bcl_address
     */
    public String getBcl_address() {
        return bcl_address;
    }

    /**
     * @param bcl_address the bcl_address to set
     */
    public void setBcl_address(String bcl_address) {
        this.bcl_address = bcl_address;
    }

    /**
     * @return the bcl_contact
     */
    public String getBcl_contact() {
        return bcl_contact;
    }

    /**
     * @param bcl_contact the bcl_contact to set
     */
    public void setBcl_contact(String bcl_contact) {
        this.bcl_contact = bcl_contact;
    }

    /**
     * @return the bcl_motif
     */
    public String getBcl_motif() {
        return bcl_motif;
    }

    /**
     * @param bcl_motif the bcl_motif to set
     */
    public void setBcl_motif(String bcl_motif) {
        this.bcl_motif = bcl_motif;
    }

    /**
     * @return the bcl_reception
     */
    public String getBcl_reception() {
        return bcl_reception;
    }

    /**
     * @param bcl_reception the bcl_reception to set
     */
    public void setBcl_reception(String bcl_reception) {
        this.bcl_reception = bcl_reception;
    }

    /**
     * @return the bcl_church
     */
    public String getBcl_church() {
        return bcl_church;
    }

    /**
     * @param bcl_church the bcl_church to set
     */
    public void setBcl_church(String bcl_church) {
        this.bcl_church = bcl_church;
    }

    /**
     * @return the bcl_wedding_date
     */
    public String getBcl_wedding_date() {
        return bcl_wedding_date;
    }

    /**
     * @param bcl_wedding_date the bcl_wedding_date to set
     */
    public void setBcl_wedding_date(String bcl_wedding_date) {
        this.bcl_wedding_date = bcl_wedding_date;
    }

    /**
     * @return the bcl_wedding_package
     */
    public String getBcl_wedding_package() {
        return bcl_wedding_package;
    }

    /**
     * @param bcl_wedding_package the bcl_wedding_package to set
     */
    public void setBcl_wedding_package(String bcl_wedding_package) {
        this.bcl_wedding_package = bcl_wedding_package;
    }

}

-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.18-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema wpbs
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ wpbs;
USE wpbs;

--
-- Table structure for table `wpbs`.`clients_booking`
--

DROP TABLE IF EXISTS `clients_booking`;
CREATE TABLE `clients_booking` (
  `idclients_booking` int(10) unsigned NOT NULL auto_increment,
  `cb_grname` varchar(45) NOT NULL default '',
  `cb_brname` varchar(45) NOT NULL default '',
  `cb_grage` varchar(45) NOT NULL default '',
  `cb_brage` varchar(45) NOT NULL default '',
  `cb_address` varchar(45) NOT NULL default '',
  `cb_contact` varchar(45) NOT NULL default '',
  `cb_motif` varchar(45) NOT NULL default '',
  `cb_reception` varchar(45) NOT NULL default '',
  `cb_church` varchar(45) NOT NULL default '',
  `cb_wedding_date` varchar(45) NOT NULL default '',
  `cb_wedding_packages` varchar(150) NOT NULL default '',
  PRIMARY KEY  (`idclients_booking`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wpbs`.`clients_booking`
--

/*!40000 ALTER TABLE `clients_booking` DISABLE KEYS */;
INSERT INTO `clients_booking` (`idclients_booking`,`cb_grname`,`cb_brname`,`cb_grage`,`cb_brage`,`cb_address`,`cb_contact`,`cb_motif`,`cb_reception`,`cb_church`,`cb_wedding_date`,`cb_wedding_packages`) VALUES 
 (1,'Ramilene Abangan','Jeffrey Gapol','21','25','Davao City','+63 - 956 - 4554 - 654','abcd','abcd','abcd','yyyy-MM-dd','?100K (50% Discount to all expenses)'),
 (2,'Ramilene Abangan','Jeffrey Gapol','21','25','Davao City','+63 - 956 - 4554 - 654','abcd','abcd','abcd','MM/d/yyyy','?200K (20% Discount free church)'),
 (3,'Ramilene Abangan','Jeffrey Gapol','21','25','Davao City','+63 - 956 - 4554 - 654','abcd','abcd','abcd','2022-11-09','?100K (50% Discount to all expenses)'),
 (4,'Ramilene Abangan','Jeffrey Gapol','21','25','Davao City','+63 - 956 - 4554 - 654','abcd','abcd','abcd','2022-11-23','?200K (20% Discount free church)'),
 (5,'Mel Gibson','Nicole Kidman','50','45','N.Y.C','+63 - 321 - 3213 - 213','abcd','abcd','abcd','2022-11-30','?100K (50% Discount to all expenses)');
/*!40000 ALTER TABLE `clients_booking` ENABLE KEYS */;


--
-- Table structure for table `wpbs`.`clients_profile`
--

DROP TABLE IF EXISTS `clients_profile`;
CREATE TABLE `clients_profile` (
  `idclients_profile` int(10) unsigned NOT NULL auto_increment,
  `groom_name` varchar(45) NOT NULL default '',
  `bride_name` varchar(45) NOT NULL default '',
  `groom_age` varchar(45) NOT NULL default '',
  `bride_age` varchar(45) NOT NULL default '',
  `address` varchar(45) NOT NULL default '',
  `contact` varchar(45) NOT NULL default '',
  PRIMARY KEY  (`idclients_profile`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wpbs`.`clients_profile`
--

/*!40000 ALTER TABLE `clients_profile` DISABLE KEYS */;
INSERT INTO `clients_profile` (`idclients_profile`,`groom_name`,`bride_name`,`groom_age`,`bride_age`,`address`,`contact`) VALUES 
 (9,'Raul N. Abangan, Jr.','Maria Lorena M. Abangan','48','47','Tres De Mayo','+63 - 943 - 2434 - 234'),
 (11,'Ramilene Abangan','Jeffrey Gapol','21','25','Davao City','+63 - 956 - 4554 - 654'),
 (12,'Mel Gibson','Nicole Kidman','50','45','N.Y.C','+63 - 321 - 3213 - 213'),
 (13,'Ramil Abangan','Jessa ','20','19','Talomo','+63 - 974 - 5523 - 231'),
 (14,'Raul Abangan, Sr.','Delia N. Lim','70','70','Talomo','+63 - 925 - 6555 - 566');
/*!40000 ALTER TABLE `clients_profile` ENABLE KEYS */;


--
-- Table structure for table `wpbs`.`planner_profile`
--

DROP TABLE IF EXISTS `planner_profile`;
CREATE TABLE `planner_profile` (
  `idplanner_profile` int(10) unsigned NOT NULL auto_increment,
  `planner_name` varchar(45) NOT NULL default '',
  `planner_username` varchar(45) NOT NULL default '',
  `planner_password` longtext NOT NULL,
  PRIMARY KEY  (`idplanner_profile`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wpbs`.`planner_profile`
--

/*!40000 ALTER TABLE `planner_profile` DISABLE KEYS */;
INSERT INTO `planner_profile` (`idplanner_profile`,`planner_name`,`planner_username`,`planner_password`) VALUES 
 (1,'Jazshynn Abangan','bea','1234');
/*!40000 ALTER TABLE `planner_profile` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
